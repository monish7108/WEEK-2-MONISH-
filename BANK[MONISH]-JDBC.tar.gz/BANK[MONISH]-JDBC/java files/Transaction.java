
public interface Transaction {
	public void  withdraw(int amount);
	public void deposit(int amount);
	public boolean checkBalance(int bal);
}
